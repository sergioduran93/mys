<?php
class VentaContraentrega extends AppModel {
	public $name = 'VentaContraentrega';
}
?>
