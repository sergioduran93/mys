<?php
class Recaudo extends AppModel {
	public $name         = 'Recaudo';
}
?>