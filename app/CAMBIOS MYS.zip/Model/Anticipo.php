<?php
class Anticipo extends AppModel {
	public $name = 'Anticipo';

	//public $belongsTo = array('Conductor');

}
?>
