<?php
class VentaCredicontadoRepre extends AppModel {
	public $name = 'VentaCredicontadoRepre';
}
?>
