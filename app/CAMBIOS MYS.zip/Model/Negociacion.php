<?php
class Negociacion extends AppModel {
	public $name = 'Negociacion';
}
?>
