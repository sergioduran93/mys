<?php
class Configuracion extends AppModel {
	public $name = 'Configuracion';
	public $actsAs = array('AuditLog.Auditable');
}
?>