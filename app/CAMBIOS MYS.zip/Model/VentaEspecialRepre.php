<?php
class VentaEspecialRepre extends AppModel {
	public $name = 'VentaEspecialRepre';
}
?>
