<?php
class Contabl extends AppModel {
	public $name = 'Contabl';
	
	//public $belongsTo = array('Conductor');

}
?>
