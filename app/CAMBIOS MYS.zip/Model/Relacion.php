<?php
class Relacion extends AppModel {
	public $name = 'Relacion';
}
?>