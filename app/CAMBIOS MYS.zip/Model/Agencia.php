<?php
class Agencia extends AppModel {
	public $name = 'Agencia';
	//public $virtualFields = array('listNombre' => 'concat(Conductor.nombre1, " ",Conductor.nombre2, " ",Conductor.apellido1," ", Conductor.apellido2)');
//	public $virtualFields = array('listNombre','CONCAT_WS(" ",Conductor.nombre1, Conductor.nombre2, Conductor.apellido1, Conductor.apellido2)');

//	public $belongsTo = array('Transportadora');

}
?>
