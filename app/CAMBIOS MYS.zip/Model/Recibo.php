<?php
class Recibo extends AppModel {
	public $name = 'Recibo';

	//public $belongsTo = array('Conductor');

}
?>
