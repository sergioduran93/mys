<?php
class Permiso extends AppModel {
	public $name = 'Permiso';
	public $displayField = 'nombre';

}
?>
