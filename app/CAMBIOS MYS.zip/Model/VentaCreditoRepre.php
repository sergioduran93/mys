<?php
class VentaCreditoRepre extends AppModel {
	public $name = 'VentaCreditoRepre';
}
?>
