<?php
class VentaEspecial extends AppModel {
	public $name = 'VentaEspecial';
}
?>
