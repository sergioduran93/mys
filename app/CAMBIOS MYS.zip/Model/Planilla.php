<?php
class Planilla extends AppModel {
	public $name = 'Planilla';

	//public $belongsTo = array('Conductor');

}
?>
