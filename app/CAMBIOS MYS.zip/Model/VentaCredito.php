<?php
class VentaCredito extends AppModel {
	public $name = 'VentaCredito';
	public $virtualFields = array('destinoNombre' => 'SELECT Destino.nombre FROM destinos as Destino WHERE Destino.id = VentaCredito.destino',
								  'origenNombre'  => 'SELECT Destino.nombre FROM destinos as Destino WHERE Destino.id = VentaCredito.origen'
	);
}
?>
