<?php
class Ventasanulada extends AppModel {
	public $name = 'Ventasanulada';
}
?>
