<?php
class VehiculoNegociacion extends AppModel {
	public $name = 'VehiculoNegociacion';
}
?>