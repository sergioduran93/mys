<?php
class Dato extends AppModel {
	public $name = 'Dato';

	//public $belongsTo = array('Conductor');

}
?>
