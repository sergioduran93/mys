<?php
class VentasCreditoController extends AppController {
	public $name = 'VentaCredito';
	public $components = array('JqImgcrop','Util','Excel');


	public function crear() {
		$this->layout = "grey";

		$clientes       = $this->VentaCredito->importModel('Cliente')->find('all',array('recursive'=>-1,'conditions'=>array('Cliente.id >'=>1,'Cliente.credito'=>'Si')));
		$clientesD      = $this->VentaCredito->importModel('Cliente')->find('list',array('fields'=>array('Cliente.documento'),'conditions'=>array('Cliente.id >'=>1,'Cliente.credito'=>'Si')));
		$clientesN      = $this->VentaCredito->importModel('Cliente')->find('list',array('fields'=>array('Cliente.listNombre'),'conditions'=>array('Cliente.id >'=>1,'Cliente.credito'=>'Si')));
		
		if(!empty($this->data)){
			$this->request->data['VentaCredito']['fecha'] = date("Y-m-d");
			$this->request->data['VentaCredito']['hora']  = date("H:i:s");
			$empaqueInfo = array();
			$this->request->data['VentaCredito']['nombreClien']    = $clientesN[$this->data['VentaCredito']['nombreClien']];
			$this->request->data['VentaCredito']['documentoClien'] = $clientesD[$this->data['VentaCredito']['documentoClien']];
			
			$this->request->data['VentaCredito']['clase']      = 'Credito';
			$empaqueInfo['barras']   = $this->data['VentaCredito']['cbarras'];
			$empaqueInfo['empaques'] = $this->data['VentaCredito']['empaques'];
			$empaqueInfo['cantidad'] = $this->data['VentaCredito']['cantidad'];
			$empaqueInfo['largo']    = $this->data['VentaCredito']['largo'];
			$empaqueInfo['ancho']    = $this->data['VentaCredito']['ancho'];
			$empaqueInfo['alto']     = $this->data['VentaCredito']['alto'];
			$empaqueInfo['peso']     = $this->data['VentaCredito']['peso'];
			$empaqueInfo['pesoVol']  = $this->data['VentaCredito']['pesoVol'];
			$empaqueInfo['valor']    = $this->data['VentaCredito']['valor'];
			$empaqueInfo['kiloAd']   = $this->data['VentaCredito']['kiloAd'];
			$empaqueInfo['subtotal'] = $this->data['VentaCredito']['subtotal'];
			$this->request->data['VentaCredito']['empaque_info'] = json_encode($empaqueInfo);

			$user   = $this->Auth->user();
			$user   = $this->VentaCredito->importModel('User')->read(null,$user['id']);
			$rem    = $this->VentaCredito->importModel('Venta')->find('first', array('order' => array('Venta.id' =>'desc'),'fields'=>'Venta.id'));
			$remesa = $user['Oficina']['codigo'].$user['User']['codigo'].(floatval($rem['Venta']['id'])+1);
			
			$this->request->data['VentaCredito']['despachada'] = $user['Oficina']['id'];
			$this->request->data['VentaCredito']['facturacion'] = '';
			$this->request->data['VentaCredito']['remesa'] = $remesa;

			$this->request->data['Venta'] = $this->data['VentaCredito'];

			$this->request->data['Venta']['kilo_adic']        = str_replace(".",",",str_replace(",","",$this->data['Venta']['kilo_adic']));
			$this->request->data['Venta']['valor_kilo_adic']  = str_replace(".",",",str_replace(",","",$this->data['Venta']['valor_kilo_adic']));
			$this->request->data['Venta']['desc_flete']       = str_replace(".",",",str_replace(",","",$this->data['Venta']['desc_flete']));
			$this->request->data['Venta']['desc_kilo']        = str_replace(".",",",str_replace(",","",$this->data['Venta']['desc_kilo']));
			$this->request->data['Venta']['valor_devolucion'] = str_replace(".",",",str_replace(",","",$this->data['Venta']['valor_devolucion']));
			$this->request->data['Venta']['valor_seguro']     = str_replace(".",",",str_replace(",","",$this->data['Venta']['valor_seguro']));
			$this->request->data['Venta']['valor_total']      = str_replace(".",",",str_replace(",","",$this->data['Venta']['valor_total']));
			
			App::import('model', 'Venta');
        	$ventaImport = new Venta();
			if($ventaImport->save($this->data)){
    			$this->Session->setFlash('','ok',array('mensaje'=>'La venta se guardo con exito.'));
				$Remite = $this->data['VentaCredito']['checkRemitente'];
				$Archiv = $this->data['VentaCredito']['checkArchivo'];
				$Destin = $this->data['VentaCredito']['checkDestinatario'];
				$Prueba = $this->data['VentaCredito']['checkPrueba'];
				$this->redirect(array('action' => 'imprimir',$ventaImport->id,$Remite,$Archiv,$Destin,$Prueba));
			} else {
    			$this->Session->setFlash('','error',array('mensaje'=>'La venta no se puedo guardar.'));
			}
		}
		$user           = $this->Auth->user();
		$user           = $this->VentaCredito->importModel('User')->read(null,$user['id']);
		$rem            = $this->VentaCredito->importModel('Venta')->find('first', array('order' => array('Venta.id' =>'desc'),'fields'=>'Venta.id'));
		$remesa         = $user['Oficina']['codigo'].$user['User']['codigo'].(floatval($rem['Venta']['id'])+1);
		$tipo           = $this->VentaCredito->getEnumValues('tipo');
		$firmado        = $this->VentaCredito->getEnumValues('firmado');
		$destinos       = $this->VentaCredito->importModel('Destino')->find('list');
		$empaques       = $this->VentaCredito->importModel('Empaque')->find('list');
		
		$remitentes     = $this->VentaCredito->importModel('Remitente')->find('all',array('recursive'=>-1));
		$remitentesD    = $this->VentaCredito->importModel('Remitente')->find('list',array('fields'=>array('Remitente.documento')));
		$remitentesNom  = $this->VentaCredito->importModel('Remitente')->find('list',array('fields'=>array('Remitente.nombre')));
		
		$destinatarios  = $this->VentaCredito->importModel('Destinatario')->find('all',array('recursive'=>-1));
		$destinatariosD = $this->VentaCredito->importModel('Destinatario')->find('list',array('fields'=>array('Destinatario.documento')));

		$remitentesN = array();
		foreach ($remitentes as $key => $value) {
			$remitentesN[$value['Remitente']['id']] = $value;
		}
		$remitentes = $remitentesN;

		$destinatariosN = array();
		foreach ($destinatarios as $key => $value) {
			$desN = json_decode($destinatarios[$key]['Destinatario']['destinos'],true);
			foreach ($desN as $key2 => $value2) {
				$destinatariosN[$value2][] = $destinatarios[$key]['Destinatario']['id'];
			}
		}
		foreach ($clientes as $key => $value) {
			$clientes[$key]['Cliente']['remitentes'] = json_decode($value['Cliente']['remitentes'],true);
		}
		
		$ingresos  = $this->VentaCredito->importModel('Ingreso')->find('list',array('fields'=>array('Ingreso.barras','Ingreso.cliente'),'conditions'=>array('Ingreso.estado'=>0)));
		$this->set(compact('ingresos','selectDep','remesa','destinos','empaques','firmado','tipo','clientes','clientesD','clientesN','remitentes','remitentesD','remitentesNom','destinatarios','destinatariosD','destinatariosN'));
	}

	public function clientes() {

		$clientes       = $this->VentaCredito->importModel('Cliente')->find('all',array('recursive'=>-1,'conditions'=>array('Cliente.id >'=>1,'Cliente.credito'=>'Si')));
		$clientesD      = $this->VentaCredito->importModel('Cliente')->find('list',array('fields'=>array('Cliente.documento'),'conditions'=>array('Cliente.id >'=>1,'Cliente.credito'=>'Si')));
		$clientesN      = $this->VentaCredito->importModel('Cliente')->find('list',array('fields'=>array('Cliente.listNombre'),'conditions'=>array('Cliente.id >'=>1,'Cliente.credito'=>'Si')));
		
		$user   = $this->Auth->user();
		$user   = $this->VentaCredito->importModel('User')->read(null,$user['id']);
		$rem    = $this->VentaCredito->find('first', array('order' => array('VentaCredito.id' =>'desc'),'fields'=>'VentaCredito.id'));
		$remesa = $user['Oficina']['codigo'].$user['User']['codigo'].(floatval($rem['VentaCredito']['id'])+1);
		
		
		if(!empty($this->data)){
			$this->request->data['VentaCredito']['fecha'] = date("Y-m-d");
			$this->request->data['VentaCredito']['hora']  = date("H:i:s");
			$empaqueInfo = array();
			$this->request->data['VentaCredito']['nombreClien']    = $clientesN[$this->data['VentaCredito']['nombreClien']];
			$this->request->data['VentaCredito']['documentoClien'] = $clientesD[$this->data['VentaCredito']['documentoClien']];
			
			$this->request->data['VentaCredito']['clase']      = 'Cliente';
			$empaqueInfo['empaques'] = $this->data['VentaCredito']['empaques'];
			$empaqueInfo['cantidad'] = $this->data['VentaCredito']['cantidad'];
			$empaqueInfo['largo']    = $this->data['VentaCredito']['largo'];
			$empaqueInfo['ancho']    = $this->data['VentaCredito']['ancho'];
			$empaqueInfo['alto']     = $this->data['VentaCredito']['alto'];
			$empaqueInfo['peso']     = $this->data['VentaCredito']['peso'];
			$empaqueInfo['pesoVol']  = $this->data['VentaCredito']['pesoVol'];
			$empaqueInfo['valor']    = $this->data['VentaCredito']['valor'];
			$empaqueInfo['kiloAd']   = $this->data['VentaCredito']['kiloAd'];
			$empaqueInfo['subtotal'] = $this->data['VentaCredito']['subtotal'];
			$this->request->data['VentaCredito']['empaque_info'] = json_encode($empaqueInfo);

			
			$this->request->data['Venta'] = $this->data['VentaCredito'];

			$this->request->data['Venta']['kilo_adic']        = str_replace(".",",",str_replace(",","",$this->data['Venta']['kilo_adic']));
			$this->request->data['Venta']['valor_kilo_adic']  = str_replace(".",",",str_replace(",","",$this->data['Venta']['valor_kilo_adic']));
			$this->request->data['Venta']['desc_flete']       = str_replace(".",",",str_replace(",","",$this->data['Venta']['desc_flete']));
			$this->request->data['Venta']['desc_kilo']        = str_replace(".",",",str_replace(",","",$this->data['Venta']['desc_kilo']));
			$this->request->data['Venta']['valor_devolucion'] = str_replace(".",",",str_replace(",","",$this->data['Venta']['valor_devolucion']));
			$this->request->data['Venta']['valor_seguro']     = str_replace(".",",",str_replace(",","",$this->data['Venta']['valor_seguro']));
			$this->request->data['Venta']['valor_total']      = str_replace(".",",",str_replace(",","",$this->data['Venta']['valor_total']));
			
			$this->request->data['VentaCredito']['facturacion'] = '';
			$this->request->data['VentaCredito']['remesa']      = $remesa;
			$this->request->data['VentaCredito']['despachada']  = $user['Oficina']['id'];

			if($this->VentaCredito->save($this->data)){
    			$this->Session->setFlash('','ok',array('mensaje'=>'La venta se guardo con exito.'));
    			$this->VentaCredito->importModel('Oficina')->save($ofi);
				$Remite = $this->data['VentaCredito']['checkRemitente'];
				$Archiv = $this->data['VentaCredito']['checkArchivo'];
				$Destin = $this->data['VentaCredito']['checkDestinatario'];
				$Prueba = $this->data['VentaCredito']['checkPrueba'];
			} else {
    			$this->Session->setFlash('','error',array('mensaje'=>'La venta no se puedo guardar.'));
			}
		}
		$tipo           = $this->VentaCredito->getEnumValues('tipo');
		$firmado        = $this->VentaCredito->getEnumValues('firmado');
		$destinos       = $this->VentaCredito->importModel('Destino')->find('list');
		$empaques       = $this->VentaCredito->importModel('Empaque')->find('list');
		
		$remitentes     = $this->VentaCredito->importModel('Remitente')->find('all',array('recursive'=>-1));
		$remitentesD    = $this->VentaCredito->importModel('Remitente')->find('list',array('fields'=>array('Remitente.documento')));
		$remitentesNom  = $this->VentaCredito->importModel('Remitente')->find('list',array('fields'=>array('Remitente.nombre')));
		
		$destinatarios  = $this->VentaCredito->importModel('Destinatario')->find('all',array('recursive'=>-1));
		$destinatariosD = $this->VentaCredito->importModel('Destinatario')->find('list',array('fields'=>array('Destinatario.documento')));

		$remitentesN = array();
		foreach ($remitentes as $key => $value) {
			$remitentesN[$value['Remitente']['id']] = $value;
		}
		$remitentes = $remitentesN;

		$destinatariosN = array();
		foreach ($destinatarios as $key => $value) {
			$desN = json_decode($destinatarios[$key]['Destinatario']['destinos'],true);
			foreach ($desN as $key2 => $value2) {
				$destinatariosN[$value2][] = $destinatarios[$key]['Destinatario']['id'];
			}
		}
		foreach ($clientes as $key => $value) {
			$clientes[$key]['Cliente']['remitentes'] = json_decode($value['Cliente']['remitentes'],true);
		}
		$this->set(compact('selectDep','remesa','destinos','empaques','firmado','tipo','clientes','clientesD','clientesN','remitentes','remitentesD','remitentesNom','destinatarios','destinatariosD','destinatariosN'));
	}

	public function getTarifa($cliente = null,$origen = null, $destino = null) {
		//$this->log($cliente.'-'.$origen.'-'.$destino);
		$this->autoRender = false;
		$tarifas   = array();
		$convenios = array();
		if(!empty($cliente) && !empty($origen) && !empty($destino)){
			$tarifas    = $this->VentaCredito->importModel("Tarifa")->find('all',array('recursive'=>-1,'conditions'=>array('Tarifa.origen'=>$origen,'Tarifa.destino'=>$destino,'Tarifa.cliente_id'=>$cliente)));
			$convenios  = $this->VentaCredito->importModel("Descuento")->find('all',array('recursive'=>-1,'conditions'=>array('Descuento.origen'=>$origen,'Descuento.destino'=>$destino,'Descuento.cliente_id'=>$cliente)));
			if($cliente != 1){
				$tarifasB   = $this->VentaCredito->importModel("Tarifa")->find('all',array('recursive'=>-1,'conditions'=>array('Tarifa.origen'=>$origen,'Tarifa.destino'=>$destino,'Tarifa.cliente_id'=>1)));
				$conveniosB = $this->VentaCredito->importModel("Descuento")->find('all',array('recursive'=>-1,'conditions'=>array('Descuento.origen'=>$origen,'Descuento.destino'=>$destino,'Descuento.cliente_id'=>1)));
			} else {
				$tarifasB   = $tarifas;
				$conveniosB = $convenios;
			}
		}
		$cupo = $this->VentaCredito->importModel('Cliente')->find('first',array('recursive'=>-1,'fields'=>array('Cliente.cupo'),'conditions'=>array('Cliente.id'=>$cliente)));
		$suma = $this->VentaCredito->importModel('Venta')->find('all',array('fields'=>array('SUM(Venta.valor_total) AS saldoPend'),'conditions'=>array('Venta.cliente'=>$cliente)));
		if($suma[0][0]['saldoPend'] == null){
			$data['Saldo'] = 0;
		} else {
			$data['Saldo'] = $suma[0][0]['saldoPend'];
		}
		$data['Cupo']         = $cupo['Cliente']['cupo'];
		$data['TarifaBase']   = $tarifasB;
		$data['ConvenioBase'] = $conveniosB;
		$data['Tarifa']       = $tarifas;
		$data['Convenio']     = $convenios;
		return json_encode($data);
	}

	public function relacion(){
		$user     = $this->Auth->user();
		$ventasL  = $this->VentaCredito->find('list',array('recursive'=>-1,'conditions'=>array('VentaCredito.cliente'=>$user['id'],'VentaCredito.despachada !='=>'Planillada')));
		if(!empty($this->data)){
			$nuevaRelacion['Relacion']['relacion'] = json_encode($ventasL);
			$this->VentaCredito->importModel('Relacion')->save($nuevaRelacion);
			$this->VentaCredito->updateAll(array('VentaCredito.despachada'=>'"Planillada"'),array('VentaCredito.cliente'=>$user['cliente_id']));
		}
		$ventas   = $this->VentaCredito->find('all',array('recursive'=>-1,'conditions'=>array('VentaCredito.cliente'=>$user['cliente_id'],'VentaCredito.despachada !='=>'Planillada')));
		$rem      = $this->VentaCredito->importModel('Relacion')->find('first', array('order' => array('Relacion.id' =>'desc'),'fields'=>'Relacion.id'));
		$planilla = (floatval($rem['Relacion']['id'])+1);
		$this->generateJSON('relacion', $ventas, array('VentaCredito' => array('id','remesa','nombreDest','direccionDest','destinoNombre','telefonoDest')));
		$this->set(compact('ventas','ventasL','planilla'));
	}

	public function imprimir($id = null, $Remite = null, $Archiv = null, $Destin = null, $Prueba = null){
		$venta               = $this->VentaCredito->importModel('Venta')->read(null,$id);
		if($Remite == '1'){
			$envio['hoja'][] = '**REMITENTE**';
		}
		if($Archiv == '1'){
			$envio['hoja'][] = '**ARCHIVO**';
		}
		if($Destin == '1'){
			$envio['hoja'][] = '**DESTINATARIO**';
		}
		if($Prueba == '1'){
			$envio['hoja'][] = '**PRUEBA DE ENTREGA**';
		}
		$envio['n']            = count($envio['hoja']);
		$envio['guia']         = $venta['Venta']['remesa'];
		$envio['contactoR']    = $venta['Venta']['contacto'];
		$envio['contactoTelR'] = $venta['Venta']['contacto_tel'];
		$oficinaB              = $this->VentaCredito->importModel('Oficina')->find('first',array('recursive'=>-1,'fields'=>array('nombre','hasta','desde','resolucion','prefijo','codigo'),'conditions'=>array('Oficina.id'=>$venta['Venta']['oficina'])));
		$envio['oficina']      = $oficinaB['Oficina']['nombre'];
		$envio['fecha']        = $venta['Venta']['fecha'];
		$envio['servicio']     = 'Envío de Encomiendas';
		$envio['docRef']       = $venta['Venta']['tipo'].' '.$venta['Venta']['documento1'];
		$envio['hora']         = $venta['Venta']['hora'];
		$envio['cliente']      = $venta['Venta']['nombreClien'];
		$envio['nit']          = $venta['Venta']['documentoClien'];
		$envio['direccionC']   = $venta['Venta']['direccionClien'];
		$envio['telefonoC']    = $venta['Venta']['telefonoClien'];
		$envio['otro_remi']    = $venta['Venta']['otro_remi'];
		if($venta['Venta']['otro_remi'] == 0){
			$envio['otro_remi']  = false;
			$envio['remitente']  = "";
			$envio['nitR']       = "";
			$envio['direccionR'] = "";
			$envio['telefonoR']  = "";
		} else {
			$envio['otro_remi']  = true;
			$envio['remitente']  = $venta['Venta']['nombreRemi'];
			$envio['nitR']       = $venta['Venta']['documentoRemi'];
			$envio['direccionR'] = $venta['Venta']['direccionRemi'];
			$envio['telefonoR']  = $venta['Venta']['telefonoRemi'];		
		}
		
		$origenB               = $this->VentaCredito->importModel('Destino')->read(null,$venta['Venta']['origen']);
		$destinoB              = $this->VentaCredito->importModel('Destino')->read(null,$venta['Venta']['destino']);
		$envio['origen']       = $origenB['Destino']['nombre'];
		$envio['destino']      = $destinoB['Destino']['nombre'];
		$destinatarioB         = $this->VentaCredito->importModel('Destinatario')->read(null,$venta['Venta']['destinatario']);
		$contactoB             = json_decode($destinatarioB['Destinatario']['contacto'],true);
		$envio['destinatario'] = $venta['Venta']['nombreDest'];
		$envio['ced']          = $venta['Venta']['documentoDest'];
		$envio['direccionD']   = $venta['Venta']['direccionDest'];
		$envio['telefonoD1']   = $venta['Venta']['telefonoDest'];
		$envio['telefonoD2']   = $contactoB[0]['telefono'];
		$envio['contacto']     = $contactoB[0]['nombre'];
		$empaques_info         = json_decode($venta['Venta']['empaque_info'],true);
		$empaquesIguales       = true;
		$sumaFlete             = 0;
		$sumaCantidad          = 0;
		$sumaPeso              = 0;
		$sumaAlto              = 0;
		$sumaAncho             = 0;
		$sumaLargo             = 0;
		$sumaPesoVol           = 0;
		$empaqueAct            = $empaques_info['empaques'][0];
		foreach ($empaques_info['empaques'] as $key => $value) {
			$sumaFlete    = $sumaFlete + ($empaques_info['cantidad'][$key]*$empaques_info['valor'][$key]);
			$sumaLargo    = $sumaLargo + $empaques_info['largo'][$key];
			$sumaAncho    = $sumaAncho + $empaques_info['ancho'][$key];
			$sumaAlto     = $sumaAlto + $empaques_info['alto'][$key];
			$sumaPeso     = $sumaPeso + ($empaques_info['cantidad'][$key]*$empaques_info['peso'][$key]);
			$sumaCantidad = $sumaCantidad + $empaques_info['cantidad'][$key];
			$sumaPesoVol  = $sumaPesoVol + ($empaques_info['cantidad'][$key]*(($empaques_info['largo'][$key]/100)*($empaques_info['ancho'][$key]/100)*($empaques_info['alto'][$key]/100)*400));
			
			if(($empaqueAct != $empaques_info['empaques'][$key]) && ($empaquesIguales)){
				$empaquesIguales = false;
			}
		}
		if($empaquesIguales){
			$empaqueB = $this->VentaCredito->importModel('Empaque')->read(null, $empaqueAct);
			$envio['empaque'] = $empaqueB['Empaque']['nombre'];
		} else {
			$envio['empaque'] = 'Otros empaques';
		}
		$envio['cantidad']    = $sumaCantidad;
		$envio['peso']        = $sumaPeso;
		$envio['pesoVol']     = $sumaPesoVol;
		if(count($empaques_info['empaques']) > 1){
			$envio['largo']   = "";
			$envio['ancho']   = "";
			$envio['alto']    = "";
		} else {
			$envio['largo']   = $sumaLargo;
			$envio['ancho']   = $sumaAncho;
			$envio['alto']    = $sumaAlto;
		}

		$envio['barras']      = $venta['Venta']['barras'];
		$envio['observacion'] = $venta['Venta']['observaciones'];
		$envio['contenido']   = $venta['Venta']['contenido'];
		$decla = str_replace(".",",",str_replace(",","",$venta['Venta']['declarado']));
		$envio['valorDecla']  = number_format(floatval($decla),0,'.',',');
		$envio['valorFlete']  = number_format($sumaFlete,0,'.',',');

		$usuarioB = $this->VentaCredito->importModel('User')->read(null,$venta['Venta']['usuario']);
		$envio['nombre']       = $usuarioB['User']['name'].' '.$usuarioB['User']['lastname'];
		$envio['formaPago']    = 'CREDITO';
		$envio['kiloAd']       = number_format(floatval($venta['Venta']['kilo_adic']),0,'.',',');
		$envio['valorKiloAd']  = number_format(floatval($venta['Venta']['valor_kilo_adic']),0,'.',',');
		$envio['descFlete']    = number_format(floatval($venta['Venta']['desc_flete']),0,'.',',');
		$envio['descKilo']     = number_format(floatval($venta['Venta']['desc_kilo']),0,'.',',');
		$envio['valorFirmado'] = number_format(floatval($venta['Venta']['valor_devolucion']),0,'.',',');
		$envio['valorSeguro']  = number_format(floatval($venta['Venta']['valor_seguro']),0,'.',',');
		$envio['valorTotal']   = number_format(floatval($venta['Venta']['valor_total']),0,'.',',');
		$envio['kiloNegoc']    = $venta['Venta']['kilo_nego'];

		$this->set(compact('envio'));
		//	$this->layout = 'pdf'; 
		//	$this->render(); 
	}

	public function editar($id = null) {
		$clientes  = $this->VentaCredito->importModel('Cliente')->find('all',array('recursive'=>-1,'conditions'=>array('Cliente.id >'=>1,'Cliente.credito'=>'Si')));
		$clientesD = $this->VentaCredito->importModel('Cliente')->find('list',array('fields'=>array('Cliente.documento'),'conditions'=>array('Cliente.id >'=>1,'Cliente.credito'=>'Si')));
		$clientesN = $this->VentaCredito->importModel('Cliente')->find('list',array('fields'=>array('Cliente.listNombre'),'conditions'=>array('Cliente.id >'=>1,'Cliente.credito'=>'Si')));
		$user      = $this->Auth->user();
		$user      = $this->VentaCredito->importModel('User')->read(null,$user['id']);
		$activo    = $this->VentaCredito->importModel('Cliente')->find('count',array('conditions'=>array('Cliente.id'=>$user['User']['cliente_id'],'Cliente.causal !='=>'Activo')));
		if($activo > 0){
			$this->Session->setFlash('','error',array('mensaje'=>'Su cuenta tiene un causal pendiente, Por favor contacte con el administrador.'));
			$this->redirect(array('controller'=>'users','action' => 'index'));
		}
		if(!empty($this->data)){
			$this->request->data['VentaCredito']['fecha'] = date("Y-m-d");
			$this->request->data['VentaCredito']['hora']  = date("H:i:s");
			$empaqueInfo = array();
			$this->request->data['VentaCredito']['despachada']     = $user['Oficina']['id'];
			$this->request->data['VentaCredito']['clase']          = 'Cliente';
			$empaqueInfo['empaques']    = $this->data['VentaCredito']['empaques'];
			$empaqueInfo['descripcion'] = $this->data['VentaCredito']['descripcion'];
			$empaqueInfo['cantidad']    = $this->data['VentaCredito']['cantidad'];
			$empaqueInfo['largo']       = $this->data['VentaCredito']['largo'];
			$empaqueInfo['ancho']       = $this->data['VentaCredito']['ancho'];
			$empaqueInfo['alto']        = $this->data['VentaCredito']['alto'];
			$empaqueInfo['peso']        = $this->data['VentaCredito']['peso'];
			$empaqueInfo['pesoVol']     = $this->data['VentaCredito']['pesoVol'];
			$empaqueInfo['valor']       = $this->data['VentaCredito']['valor'];
			$empaqueInfo['kiloAd']      = $this->data['VentaCredito']['kiloAd'];
			$this->request->data['VentaCredito']['empaque_info'] = json_encode($empaqueInfo);

			if($this->VentaCredito->save($this->data)){
    			$this->Session->setFlash('','ok',array('mensaje'=>'La venta se guardo con exito.'));
			} else {
    			$this->Session->setFlash('','error',array('mensaje'=>'La venta no se puedo guardar.'));
			}
		}

		$guiaEditar  = $this->VentaCredito->read(null,$id);
		$empaqueInfo = json_decode($guiaEditar['VentaCredito']['empaque_info'],true);
		$empaqueKO   = array();
		foreach ($empaqueInfo['empaques'] as $key => $value) {
			$empaqueKO[$key]['empaques']    = $empaqueInfo['empaques'][$key];
			$empaqueKO[$key]['descripcion'] = $empaqueInfo['descripcion'][$key];
			$empaqueKO[$key]['cantidad']    = $empaqueInfo['cantidad'][$key];
			$empaqueKO[$key]['valKilo']     = 0;
			$empaqueKO[$key]['pesoUni']     = 0;
			$empaqueKO[$key]['largo']       = $empaqueInfo['largo'][$key];
			$empaqueKO[$key]['ancho']       = $empaqueInfo['ancho'][$key];
			$empaqueKO[$key]['alto']        = $empaqueInfo['alto'][$key];
			$empaqueKO[$key]['peso']        = $empaqueInfo['peso'][$key];
			$empaqueKO[$key]['pesoVol']     = $empaqueInfo['pesoVol'][$key];
			$empaqueKO[$key]['valor']       = $empaqueInfo['valor'][$key];
			$empaqueKO[$key]['kiloAd']      = $empaqueInfo['kiloAd'][$key];
		}
		$guiaEditar['VentaCredito']['empaque_info'] = json_encode($empaqueKO);

		$this->data = $guiaEditar;

		$tipo           = $this->VentaCredito->getEnumValues('tipo');
		$firmado        = $this->VentaCredito->getEnumValues('firmado');
		$destinos       = $this->VentaCredito->importModel('Destino')->find('list');
		$empaques       = $this->VentaCredito->importModel('Empaque')->find('list');
		
		$remitentes     = $this->VentaCredito->importModel('Remitente')->find('all',array('recursive'=>-1));
		$remitentesD    = $this->VentaCredito->importModel('Remitente')->find('list',array('fields'=>array('Remitente.documento')));
		$remitentesNom  = $this->VentaCredito->importModel('Remitente')->find('list',array('fields'=>array('Remitente.nombre')));
		
		$destinatarios  = $this->VentaCredito->importModel('Destinatario')->find('all',array('recursive'=>-1));
		$destinatariosD = $this->VentaCredito->importModel('Destinatario')->find('list',array('fields'=>array('Destinatario.documento')));

		$remitentesN = array();
		foreach ($remitentes as $key => $value) {
			$remitentesN[$value['Remitente']['id']] = $value;
		}
		$remitentes = $remitentesN;

		$destinatariosN = array();
		foreach ($destinatarios as $key => $value) {
			$desN = json_decode($destinatarios[$key]['Destinatario']['destinos'],true);
			foreach ($desN as $key2 => $value2) {
				$destinatariosN[$value2][] = $destinatarios[$key]['Destinatario']['id'];
			}
		}
		foreach ($clientes as $key => $value) {
			$clientes[$key]['Cliente']['remitentes'] = json_decode($value['Cliente']['remitentes'],true);
		}
		$this->set(compact('selectDep','remesa','destinos','empaques','firmado','tipo','clientes','clientesD','clientesN','remitentes','remitentesD','remitentesNom','destinatarios','destinatariosD','destinatariosN'));
	}

	public function eliminar($id = null) {
		if($this->VentaCredito->delete($id)){
			$this->Session->setFlash('','ok',array('mensaje'=>'La guia se elimino con exito'));
		} else {
			$this->Session->setFlash('','error',array('mensaje'=>'La guia no se pudo eliminar'));
		}
		$this->redirect(array('action' => 'relacion'));
	}

	public function reliquidar(){
		$user     = $this->Auth->user();
		$ventasL  = $this->VentaCredito->find('list',array('recursive'=>-1,'conditions'=>array('VentaCredito.cliente'=>$user['id'],'VentaCredito.despachada !='=>'Planillada')));
		if(!empty($this->data)){
			$nuevaRelacion['Relacion']['relacion'] = json_encode($ventasL);
			$this->VentaCredito->importModel('Relacion')->save($nuevaRelacion);
			$this->VentaCredito->updateAll(array('VentaCredito.despachada'=>'"Planillada"'),array('VentaCredito.cliente'=>$user['cliente_id']));
		}

		$ventas   = $this->VentaCredito->find('all',array('recursive'=>-1,'conditions'=>array()));
		
		$this->generateJSON('relacion', $ventas, array('VentaCredito' => array('id','remesa','nombreDest','direccionDest','destinoNombre','telefonoDest')));
		$this->set(compact('ventas','ventasL'));
	}

	public function getReliquidar2($id = null) {
		$this->layout = 'empty';
		$empaques = $this->VentaCredito->importModel('Empaque')->find('list');
		$guia     = $this->VentaCredito->read(null,$id);
		if(!empty($this->data)){
			$guia = $this->VentaCredito->read(null,$this->data['VentaCredito']['id']);
			$empaqueInfo = array();
			$empaqueInfo['barras']   = $this->data['VentaCredito']['cbarras'];
			$empaqueInfo['empaques'] = $this->data['VentaCredito']['empaques'];
			$empaqueInfo['cantidad'] = $this->data['VentaCredito']['cantidad'];
			$empaqueInfo['largo']    = $this->data['VentaCredito']['largo'];
			$empaqueInfo['ancho']    = $this->data['VentaCredito']['ancho'];
			$empaqueInfo['alto']     = $this->data['VentaCredito']['alto'];
			$empaqueInfo['peso']     = $this->data['VentaCredito']['peso'];
			$empaqueInfo['pesoVol']  = $this->data['VentaCredito']['pesoVol'];
			$empaqueInfo['valor']    = $this->data['VentaCredito']['valor'];
			$empaqueInfo['kiloAd']   = $this->data['VentaCredito']['kiloAd'];
			$empaqueInfo['subtotal'] = $this->data['VentaCredito']['subtotal'];
			$guia['VentaCredito']['empaque_info']    = json_encode($empaqueInfo);
			$guia['VentaCredito']['kilo_nego']       = $this->data['VentaCredito']['kilo_nego'];
			$guia['VentaCredito']['kilo_adic']       = $this->data['VentaCredito']['kilo_adic'];
			$guia['VentaCredito']['valor_kilo_adic'] = $this->data['VentaCredito']['valor_kilo_adic'];
			$guia['VentaCredito']['desc_flete']      = $this->data['VentaCredito']['desc_flete'];
			$guia['VentaCredito']['desc_kilo']       = $this->data['VentaCredito']['desc_kilo'];
			$guia['VentaCredito']['valor_total']     = $this->data['VentaCredito']['valor_total'];
			$guia['VentaCredito']['despachada']      = $this->data['VentaCredito']['valor_total'];
			$guia['Venta'] = $guia['VentaCredito'];
			$guia['Venta']['id'] = "";
			if($this->VentaCredito->importModel('Venta')->save($guia)){
				$this->VentaCredito->delete($this->data['VentaCredito']['id']);
    			$this->Session->setFlash('','ok',array('mensaje'=>'La guia se reliquido exitosamente.'));
			} else {
    			$this->Session->setFlash('','error',array('mensaje'=>'La guia no se puedo reliquidar.'));
			}
		}
		if($id == null){
			$this->data = null;
		} else {
			$this->data = $guia;
		}
		
		$cliente = $guia['VentaCredito']['cliente'];
		$origen  = $guia['VentaCredito']['origen'];
		$destino = $guia['VentaCredito']['destino'];

		$tarifas   = array();
		$convenios = array();
		if(!empty($cliente) && !empty($origen) && !empty($destino)){
			$tarifas    = $this->VentaCredito->importModel("Tarifa")->find('all',array('recursive'=>-1,'conditions'=>array('Tarifa.origen'=>$origen,'Tarifa.destino'=>$destino,'Tarifa.cliente_id'=>$cliente)));
			$convenios  = $this->VentaCredito->importModel("Descuento")->find('all',array('recursive'=>-1,'conditions'=>array('Descuento.origen'=>$origen,'Descuento.destino'=>$destino,'Descuento.cliente_id'=>$cliente)));
			if($cliente != 1){
				$tarifasB   = $this->VentaCredito->importModel("Tarifa")->find('all',array('recursive'=>-1,'conditions'=>array('Tarifa.origen'=>$origen,'Tarifa.destino'=>$destino,'Tarifa.cliente_id'=>1)));
				$conveniosB = $this->VentaCredito->importModel("Descuento")->find('all',array('recursive'=>-1,'conditions'=>array('Descuento.origen'=>$origen,'Descuento.destino'=>$destino,'Descuento.cliente_id'=>1)));
			} else {
				$tarifasB   = $tarifas;
				$conveniosB = $convenios;
			}
		}
		
		$data['TarifaBase']   = $tarifasB;
		$data['ConvenioBase'] = $conveniosB;
		$data['Tarifa']       = $tarifas;
		$data['Convenio']     = $convenios;
		$data = json_encode($data);

		$empaqueInfo = json_decode($guia['VentaCredito']['empaque_info'],true);
		$empaqueKO   = array();
		$cantidadCheck = 0;
		foreach ($empaqueInfo['empaques'] as $key => $value) {
			$empaqueKO[$key]['empaques']    = $empaqueInfo['empaques'][$key];
			$empaqueKO[$key]['descripcion'] = $empaqueInfo['descripcion'][$key];
			$empaqueKO[$key]['cantidad']    = $empaqueInfo['cantidad'][$key];
			$cantidadCheck = $cantidadCheck + floatval($empaqueInfo['cantidad'][$key]);
			$empaqueKO[$key]['valKilo']     = 0;
			$empaqueKO[$key]['pesoUni']     = 0;
			$empaqueKO[$key]['largo']       = $empaqueInfo['largo'][$key];
			$empaqueKO[$key]['ancho']       = $empaqueInfo['ancho'][$key];
			$empaqueKO[$key]['alto']        = $empaqueInfo['alto'][$key];
			$empaqueKO[$key]['peso']        = $empaqueInfo['peso'][$key];
			$empaqueKO[$key]['pesoVol']     = $empaqueInfo['pesoVol'][$key];
			$empaqueKO[$key]['valor']       = $empaqueInfo['valor'][$key];
			$empaqueKO[$key]['kiloAd']      = $empaqueInfo['kiloAd'][$key];
		}
		$empaque_info = json_encode($empaqueKO);
		$costoSeguro  = $guia['VentaCredito']['valor_seguro'];
		$costoDevol   = $guia['VentaCredito']['valor_devolucion'];
		$this->set(compact('cantidadCheck','costoDevol','costoSeguro','empaques','data','empaque_info'));
	}

	public function getReliquidar($id = null) {
		$this->layout = 'empty';
		$empaques = $this->VentaCredito->importModel('Empaque')->find('list');
		$guia     = $this->VentaCredito->read(null,$id);
		$recibo   = $this->VentaCredito->importModel('Recibo')->find('count',array('conditions'=>array('Recibo.guia_id'=>$id)));
		if(!empty($this->data)){
			$guia = $this->VentaCredito->read(null,$this->data['VentaCredito']['id']);
			$empaqueInfo = array();
			$empaqueInfo['barras']      = $this->data['VentaCredito']['cbarras'];
			$empaqueInfo['descripcion'] = $this->data['VentaCredito']['descripcion'];
			$empaqueInfo['empaques']    = $this->data['VentaCredito']['empaques'];
			$empaqueInfo['cantidad']    = $this->data['VentaCredito']['cantidad'];
			$empaqueInfo['largo']       = $this->data['VentaCredito']['largo'];
			$empaqueInfo['ancho']       = $this->data['VentaCredito']['ancho'];
			$empaqueInfo['alto']        = $this->data['VentaCredito']['alto'];
			$empaqueInfo['peso']        = $this->data['VentaCredito']['peso'];
			$empaqueInfo['pesoVol']     = $this->data['VentaCredito']['pesoVol'];
			$empaqueInfo['valor']       = $this->data['VentaCredito']['valor'];
			$empaqueInfo['kiloAd']      = $this->data['VentaCredito']['kiloAd'];
			$empaqueInfo['subtotal']    = $this->data['VentaCredito']['subtotal'];
			$guia['VentaCredito']['empaque_info']    = json_encode($empaqueInfo);
			$guia['VentaCredito']['despachada']      = $this->data['VentaCredito']['oficina_trae'];
			$guia['VentaCredito']['lista']           = 1;
			$guia['VentaCredito']['clase']           = 'Credito';
			$guia['VentaCredito']['kilo_nego']       = $this->data['VentaCredito']['kilo_nego'];
			$guia['VentaCredito']['kilo_adic']       = $this->data['VentaCredito']['kilo_adic'];
			$guia['VentaCredito']['valor_kilo_adic'] = $this->data['VentaCredito']['valor_kilo_adic'];
			$guia['VentaCredito']['desc_flete']      = $this->data['VentaCredito']['desc_flete'];
			$guia['VentaCredito']['desc_kilo']       = $this->data['VentaCredito']['desc_kilo'];
			$guia['VentaCredito']['valor_total']     = $this->data['VentaCredito']['valor_total'];
			$guia['Venta'] = $guia['VentaCredito'];
			$guia['Venta']['id'] = '';
			$idd = $this->request->data['Venta']['id'];
			$this->request->data['Venta'] = $guia['VentaCredito'];
			$this->request->data['Venta']['id'] = '';

			unset($guia['VentaCredito']);
			$this->VentaCredito->importModel('Venta')->create();
			if($this->VentaCredito->importModel('Venta')->save($guia)){
				$this->VentaCredito->delete($idd);
    			$this->Session->setFlash('','ok',array('mensaje'=>'La guia se reliquido exitosamente.'));
			} else {
    			$this->Session->setFlash('','error',array('mensaje'=>'La guia no se puedo reliquidar.'));
			}
		}
		if($id == null){
			$this->data = null;
		} else {
			$this->data = $guia;
		}
		
		$cliente = $guia['VentaCredito']['cliente'];
		$origen  = $guia['VentaCredito']['origen'];
		$destino = $guia['VentaCredito']['destino'];

		$tarifas   = array();
		$convenios = array();
		if(!empty($cliente) && !empty($origen) && !empty($destino)){
			$tarifas    = $this->VentaCredito->importModel("Tarifa")->find('all',array('recursive'=>-1,'conditions'=>array('Tarifa.origen'=>$origen,'Tarifa.destino'=>$destino,'Tarifa.cliente_id'=>$cliente)));
			$convenios  = $this->VentaCredito->importModel("Descuento")->find('all',array('recursive'=>-1,'conditions'=>array('Descuento.origen'=>$origen,'Descuento.destino'=>$destino,'Descuento.cliente_id'=>$cliente)));
			if($cliente != 1){
				$tarifasB   = $this->VentaCredito->importModel("Tarifa")->find('all',array('recursive'=>-1,'conditions'=>array('Tarifa.origen'=>$origen,'Tarifa.destino'=>$destino,'Tarifa.cliente_id'=>1)));
				$conveniosB = $this->VentaCredito->importModel("Descuento")->find('all',array('recursive'=>-1,'conditions'=>array('Descuento.origen'=>$origen,'Descuento.destino'=>$destino,'Descuento.cliente_id'=>1)));
			} else {
				$tarifasB   = $tarifas;
				$conveniosB = $convenios;
			}
		}
		
		$data['TarifaBase']   = $tarifasB;
		$data['ConvenioBase'] = $conveniosB;
		$data['Tarifa']       = $tarifas;
		$data['Convenio']     = $convenios;
		$data = json_encode($data);

		$empaqueInfo = json_decode($guia['VentaCredito']['empaque_info'],true);
		$empaqueKO   = array();
		$cantidadCheck = 0;
		foreach ($empaqueInfo['empaques'] as $key => $value) {
			$empaqueKO[$key]['empaques']    = $empaqueInfo['empaques'][$key];
			$empaqueKO[$key]['descripcion'] = $empaqueInfo['descripcion'][$key];
			$empaqueKO[$key]['cantidad']    = $empaqueInfo['cantidad'][$key];
			$cantidadCheck = $cantidadCheck + floatval($empaqueInfo['cantidad'][$key]);
			$empaqueKO[$key]['valKilo']     = 0;
			$empaqueKO[$key]['pesoUni']     = 0;
			$empaqueKO[$key]['largo']       = $empaqueInfo['largo'][$key];
			$empaqueKO[$key]['ancho']       = $empaqueInfo['ancho'][$key];
			$empaqueKO[$key]['alto']        = $empaqueInfo['alto'][$key];
			$empaqueKO[$key]['peso']        = $empaqueInfo['peso'][$key];
			$empaqueKO[$key]['pesoVol']     = number_format(floatval($empaqueInfo['pesoVol'][$key]),2);
			$empaqueKO[$key]['valor']       = $empaqueInfo['valor'][$key];
			$empaqueKO[$key]['kiloAd']      = $empaqueInfo['kiloAd'][$key];
		}
		$empaque_info = json_encode($empaqueKO);
		$costoSeguro  = $guia['VentaCredito']['valor_seguro'];
		$costoDevol   = $guia['VentaCredito']['valor_devolucion'];
		$this->set(compact('recibo','cantidadCheck','costoDevol','costoSeguro','empaques','data','empaque_info'));
	}

	public function importar(){
		if(!empty($this->data)){
			$file = $this->data['VentaCredito']['excel']['tmp_name'];
			move_uploaded_file($file, 'files/excel/'.$this->data['VentaCredito']['excel']['name']);
			if(!empty($file)){
				$dataExcel = $this->Excel->readVenta('files/excel/'.$this->data['VentaCredito']['excel']['name']);				
			}
			$user     = $this->Auth->user();
			$user     = $this->VentaCredito->importModel('User')->read(null,$user['id']);
			$cliente  = $this->VentaCredito->importModel('Cliente')->read(null,$user['User']['cliente_id']);
			$rem      = $this->VentaCredito->importModel('Venta')->find('first', array('order' => array('Venta.id' =>'desc'),'fields'=>'Venta.id'));
			$remesa   = floatval($rem['Venta']['id'])+1;
			$ventas   = array();
			$destinos = $this->VentaCredito->importModel('Destino')->find('list');
			$empaqueInfo = array();
			$remi = $dataExcel[0][4];
			foreach ($dataExcel as $key => $value) {
				if($value[20] == "SOBRE"){
					$empaqueInfo['empaques'][] = '1';
				} else if($value[20] == "PAQUETE"){
					$empaqueInfo['empaques'][] = '2';
				} else if($value[20] == "CAJA"){
					$empaqueInfo['empaques'][] = '3';
				} else if($value[20] == "OTROS"){
					$empaqueInfo['empaques'][] = '5';
				}
				$empaqueInfo['cantidad'][] = $value[23];
				$empaqueInfo['largo'][]    = $value[25];
				$empaqueInfo['ancho'][]    = $value[26];
				$empaqueInfo['alto'][]     = $value[27];
				$empaqueInfo['peso'][]     = $value[24]*$value[23];
				$empaqueInfo['pesoVol'][]  = '0';
				$empaqueInfo['valor'][]    = '0';
				$empaqueInfo['kiloAd'][]   = '0';
				$empaqueInfo['subtotal'][] = '0';

				if($remi != $value[4] || (count($dataExcel) == ($key+1))){
					$guia['VentaCredito']['oficina']        = $user['User']['oficina_id'];
					$guia['VentaCredito']['remesa']         = $user['User']['oficina_id'].$user['User']['codigo'].'-'.($key+$remesa);
					$guia['VentaCredito']['documento1']     = $value[0];
					$guia['VentaCredito']['documento2']     = $value[2];
					$guia['VentaCredito']['documento3']     = $value[3];
					$guia['VentaCredito']['tipo']           = $value[1];
					$guia['VentaCredito']['cliente']        = $user['User']['cliente_id'];
					$guia['VentaCredito']['contacto']       = $value[10];
					$guia['VentaCredito']['origen']         = array_search($value[11], $destinos);
					$guia['VentaCredito']['destino']        = array_search($value[12], $destinos);
					if($value[30] == "SI"){
						$guia['VentaCredito']['firmado']        = "Si";
					} else {
						$guia['VentaCredito']['firmado']        = "No";
					}
					$guia['VentaCredito']['contenido']      = $value[29];
					$guia['VentaCredito']['fecha']          = date("Y-m-d");
					$guia['VentaCredito']['hora']           = date("H:i:s");
					$guia['VentaCredito']['declarado']      = $value[28];
					$guia['VentaCredito']['empaque_info']   = json_encode($empaqueInfo);
					$guia['VentaCredito']['usuario']        = $user['User']['id'];
					$guia['VentaCredito']['faxDest']        = $value[19];
					$guia['VentaCredito']['emailDest']      = $value[18];
					$guia['VentaCredito']['telefono2Dest']  = $value[17];
					$guia['VentaCredito']['telefonoDest']   = $value[16];
					$guia['VentaCredito']['direccionDest']  = $value[15];
					$guia['VentaCredito']['nombreDest']     = $value[14];
					$guia['VentaCredito']['documentoDest']  = $value[13];
					$guia['VentaCredito']['emailRemi']      = $value[9];
					$guia['VentaCredito']['celularRemi']    = $value[7];
					$guia['VentaCredito']['telefonoRemi']   = $value[8];
					$guia['VentaCredito']['direccionRemi']  = $value[6];
					$guia['VentaCredito']['nombreRemi']     = $value[5];
					$guia['VentaCredito']['documentoRemi']  = $value[4];
					$guia['VentaCredito']['faxClien']       = $cliente['Cliente']['fax'];
					$guia['VentaCredito']['emailClien']     = $cliente['Cliente']['email'];
					$guia['VentaCredito']['telefono2Clien'] = $cliente['Cliente']['telefono2'];
					$guia['VentaCredito']['telefonoClien']  = $cliente['Cliente']['telefono'];
					$guia['VentaCredito']['direccionClien'] = $cliente['Cliente']['direccion'];
					$guia['VentaCredito']['nombreClien']    = $cliente['Cliente']['listNombre'];
					$guia['VentaCredito']['documentoClien'] = $cliente['Cliente']['documento'];
					$guia['VentaCredito']['clase']          = 'Credito';
					$guia['VentaCredito']['despachada']     = $user['User']['oficina_id'];
					$ventas[] = $guia;
					$empaqueInfo = array();
				}

			}
			//$ventas[] = $guia;
			$this->log($ventas);
			if($this->VentaCredito->saveAll($ventas)){
    			$this->Session->setFlash('','ok',array('mensaje'=>'La importación se guardo con exito.'));
			} else {
    			$this->Session->setFlash('','error',array('mensaje'=>'La importación no se puedo guardar.'));
			}
		}
	}
}
?>
