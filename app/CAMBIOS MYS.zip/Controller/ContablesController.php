<?php
class ContablesController extends AppController {
	public $name = 'Contables';

	public function egresos() {
		if(!empty($this->data)){
			$count = $this->Contabl->find('count',array('conditions'=>array('Contabl.tipo'=>"EGRESO")));
			$count += 1;
			$this->request->data['Contabl']['numero'] = $count;
			$this->request->data['Contabl']['fecha']  = date('Y-m-d h:i:s');
			$this->request->data['Contabl']['tipo']   = "EGRESO";
			if($this->Contabl->save($this->data)){
	   			$this->Session->setFlash('','ok',array('mensaje'=>'El egreso se guardo con exito'));
			} else {
		   		$this->Session->setFlash('','error',array('mensaje'=>'El egreso no se pudo guardar'));
			}
		}
		$this->data = null;

		$count = $this->Contabl->find('count',array('conditions'=>array('Contabl.tipo'=>"EGRESO")));
		$count += 1;
		$cuentas  = $this->Contabl->importModel('Cuenta')->find('list');
		$oficinas = $this->Contabl->importModel('Oficina')->find('list');
		$this->set(compact('cuentas','oficinas','count'));
	}

	public function eliminar($id = null) {
		if($this->Cuenta->delete($id)){
	   		$this->Session->setFlash('','ok',array('mensaje'=>'La cuenta se elimino con exito'));
		} else {
	   		$this->Session->setFlash('','error',array('mensaje'=>'La cuenta no se pudo eliminar'));
		}
    	$this->redirect(array('action' => 'crear'));
	}
}
?>
