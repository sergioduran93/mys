<?php
class VentasCreditoRepreController extends AppController {
	public $name = 'VentaCreditoRepre';

	public function crear() {
		$this->layout = "grey";

		$clientes       = $this->VentaCreditoRepre->importModel('Cliente')->find('all',array('recursive'=>-1,'conditions'=>array('Cliente.id >'=>1,'Cliente.credito'=>'Si')));
		$clientesD      = $this->VentaCreditoRepre->importModel('Cliente')->find('list',array('fields'=>array('Cliente.documento'),'conditions'=>array('Cliente.id >'=>1,'Cliente.credito'=>'Si')));
		$clientesN      = $this->VentaCreditoRepre->importModel('Cliente')->find('list',array('fields'=>array('Cliente.listNombre'),'conditions'=>array('Cliente.id >'=>1,'Cliente.credito'=>'Si')));
		
		$user   = $this->Auth->user();
		$user   = $this->VentaCreditoRepre->importModel('User')->read(null,$user['id']);
		$rem    = $this->VentaCreditoRepre->importModel('Venta')->find('first', array('order' => array('Venta.id' =>'desc'),'fields'=>'Venta.id'));
		$remesa = $user['Oficina']['codigo'].$user['User']['codigo'].(floatval($rem['Venta']['id'])+1);
	
		if(!empty($this->data)){
			$this->request->data['VentaCreditoRepre']['fecha'] = date("Y-m-d");
			$this->request->data['VentaCreditoRepre']['hora']  = date("H:i:s");
			$empaqueInfo = array();
			$this->request->data['VentaCreditoRepre']['nombreClien']    = $clientesN[$this->data['VentaCreditoRepre']['nombreClien']];
			$this->request->data['VentaCreditoRepre']['documentoClien'] = $clientesD[$this->data['VentaCreditoRepre']['documentoClien']];
			$this->request->data['VentaCreditoRepre']['clase']      = 'Credito';
			$this->request->data['VentaCreditoRepre']['despachada'] = $user['Oficina']['id'];
			$empaqueInfo['empaques'] = $this->data['VentaCreditoRepre']['empaques'];
			$empaqueInfo['cantidad'] = $this->data['VentaCreditoRepre']['cantidad'];
			$empaqueInfo['barras']      = $this->data['VentaCreditoRepre']['cbarras'];
			$empaqueInfo['descripcion'] = $this->data['VentaCreditoRepre']['descripcion'];
			$empaqueInfo['largo']    = $this->data['VentaCreditoRepre']['largo'];
			$empaqueInfo['ancho']    = $this->data['VentaCreditoRepre']['ancho'];
			$empaqueInfo['alto']     = $this->data['VentaCreditoRepre']['alto'];
			$empaqueInfo['peso']     = $this->data['VentaCreditoRepre']['peso'];
			$empaqueInfo['pesoVol']  = $this->data['VentaCreditoRepre']['pesoVol'];
			$empaqueInfo['valor']    = $this->data['VentaCreditoRepre']['valor'];
			$empaqueInfo['kiloAd']   = $this->data['VentaCreditoRepre']['kiloAd'];
			$empaqueInfo['subtotal'] = $this->data['VentaCreditoRepre']['subtotal'];
			$this->request->data['VentaCreditoRepre']['empaque_info'] = json_encode($empaqueInfo);

			$this->request->data['VentaCreditoRepre']['facturacion'] = "";
			$this->request->data['VentaCreditoRepre']['remesa']      = $remesa;
			$this->request->data['Venta'] = $this->data['VentaCreditoRepre'];
			App::import('model', 'Venta');
        	$ventaImport = new Venta();
			if($ventaImport->save($this->data)){
    			$this->Session->setFlash('','ok',array('mensaje'=>'La venta se guardo con exito.'));
				if($user['User']['oficina_id'] != 7){
					$this->request->data['Venta']['guia_id'] = $ventaImport->id;
					$this->request->data['Venta']['fecha']   = $this->data['Venta']['fecha'].' '.$this->data['Venta']['hora'];
    				if($this->data['Venta']['checkNatural'] == 1){
    					$this->request->data['Venta']['tipo'] = 'Natural';
    				} else {
						$this->request->data['Venta']['tipo']           = 'Juridica';
    					$repre = $this->VentaCreditoRepre->importModel('Representante')->read(null,$this->data['Venta']['recaudador']);
						$this->request->data['Venta']['negociador']     = $repre['Representante']['identificacion'];
						$this->request->data['Venta']['negociador_nom'] = $repre['Representante']['listNombre'];
    				}
    				$recibo = $this->request->data['Venta'];
					$this->request->data['VentaCreditoRepre']['fecha'] = date("Y-m-d H:i:s");
    				$this->VentaCreditoRepre->importModel('Recibo')->save($recibo);
    			}
				$Remite = $this->data['VentaCreditoRepre']['checkRemitente'];
				$Archiv = $this->data['VentaCreditoRepre']['checkArchivo'];
				$Destin = $this->data['VentaCreditoRepre']['checkDestinatario'];
				$Prueba = $this->data['VentaCreditoRepre']['checkPrueba'];
				$this->redirect(array('controller'=>'ventascredito','action' => 'imprimir',$ventaImport->id,$Remite,$Archiv,$Destin,$Prueba));
			} else {
    			$this->Session->setFlash('','error',array('mensaje'=>'La venta no se puedo guardar.'));
			}
		}
		$user           = $this->Auth->user();
		$user           = $this->VentaCreditoRepre->importModel('User')->read(null,$user['id']);
		$remesa         = $user['Oficina']['codigo'].$user['User']['codigo'].floatval($user['Oficina']['consecutivo']);
		$tipo           = $this->VentaCreditoRepre->getEnumValues('tipo');
		$firmado        = $this->VentaCreditoRepre->getEnumValues('firmado');
		$destinos       = $this->VentaCreditoRepre->importModel('Destino')->find('list');
		$empaques       = $this->VentaCreditoRepre->importModel('Empaque')->find('list');
		
		$remitentes     = $this->VentaCreditoRepre->importModel('Remitente')->find('all',array('recursive'=>-1));
		$remitentesD    = $this->VentaCreditoRepre->importModel('Remitente')->find('list',array('fields'=>array('Remitente.documento')));
		$remitentesNom  = $this->VentaCreditoRepre->importModel('Remitente')->find('list',array('fields'=>array('Remitente.nombre')));
		
		$destinatarios  = $this->VentaCreditoRepre->importModel('Destinatario')->find('all',array('recursive'=>-1));
		$destinatariosD = $this->VentaCreditoRepre->importModel('Destinatario')->find('list',array('fields'=>array('Destinatario.documento')));

		$remitentesN = array();
		foreach ($remitentes as $key => $value) {
			$remitentesN[$value['Remitente']['id']] = $value;
		}
		$remitentes = $remitentesN;

		$destinatariosN = array();
		foreach ($destinatarios as $key => $value) {
			$desN = json_decode($destinatarios[$key]['Destinatario']['destinos'],true);
			foreach ($desN as $key2 => $value2) {
				$destinatariosN[$value2][] = $destinatarios[$key]['Destinatario']['id'];
			}
		}
		foreach ($clientes as $key => $value) {
			$clientes[$key]['Cliente']['remitentes'] = json_decode($value['Cliente']['remitentes'],true);
		}
		$transportadoras = $this->VentaCreditoRepre->importModel('Transportadora')->find('all',array('recursive'=>-1,'fields'=>array('Transportadora.nit','Transportadora.razon','Transportadora.credito')));
		$vehiculos       = $this->VentaCreditoRepre->importModel('Vehiculo')->find('list');
		$vehiculos       = array_values($vehiculos);
		$conductores     = $this->VentaCreditoRepre->importModel('Conductor')->find('all',array('recursive'=>-1,'fields'=>array('Conductor.identificacion','Conductor.listNombre'),'conditions'=>array('Conductor.conductor2'=>'1')));
		$forma           = $this->VentaCreditoRepre->importModel('Recibo')->getEnumValues('forma_pago');

		$ingresos  = $this->VentaCreditoRepre->importModel('Ingreso')->find('list',array('fields'=>array('Ingreso.barras','Ingreso.cliente'),'conditions'=>array('Ingreso.estado'=>0)));
		$this->set(compact('ingresos','transportadoras','forma','conductores','vehiculos','selectDep','remesa','destinos','empaques','firmado','tipo','clientes','clientesD','clientesN','remitentes','remitentesD','remitentesNom','destinatarios','destinatariosD','destinatariosN'));
	}

	public function getTarifa($cliente = null,$origen = null, $destino = null) {
		//$this->log($cliente.'-'.$origen.'-'.$destino);
		$this->autoRender = false;
		$tarifas   = array();
		$convenios = array();
		if(!empty($cliente) && !empty($origen) && !empty($destino)){
			$tarifas    = $this->VentaCreditoRepre->importModel("Tarifa")->find('all',array('recursive'=>-1,'conditions'=>array('Tarifa.origen'=>$origen,'Tarifa.destino'=>$destino,'Tarifa.cliente_id'=>$cliente)));
			$convenios  = $this->VentaCreditoRepre->importModel("Descuento")->find('all',array('recursive'=>-1,'conditions'=>array('Descuento.origen'=>$origen,'Descuento.destino'=>$destino,'Descuento.cliente_id'=>$cliente)));
			if($cliente != 1){
				$tarifasB   = $this->VentaCreditoRepre->importModel("Tarifa")->find('all',array('recursive'=>-1,'conditions'=>array('Tarifa.origen'=>$origen,'Tarifa.destino'=>$destino,'Tarifa.cliente_id'=>1)));
				$conveniosB = $this->VentaCreditoRepre->importModel("Descuento")->find('all',array('recursive'=>-1,'conditions'=>array('Descuento.origen'=>$origen,'Descuento.destino'=>$destino,'Descuento.cliente_id'=>1)));
			} else {
				$tarifasB   = $tarifas;
				$conveniosB = $convenios;
			}
		}
		$cupo = $this->VentaCreditoRepre->importModel('Cliente')->find('first',array('recursive'=>-1,'fields'=>array('Cliente.cupo'),'conditions'=>array('Cliente.id'=>$cliente)));
		$suma = $this->VentaCreditoRepre->importModel('Venta')->find('all',array('fields'=>array('SUM(Venta.valor_total) AS saldoPend'),'conditions'=>array('Venta.cliente'=>$cliente)));
		if($suma[0][0]['saldoPend'] == null){
			$data['Saldo'] = 0;
		} else {
			$data['Saldo'] = $suma[0][0]['saldoPend'];
		}
		$data['Cupo']             = $cupo['Cliente']['cupo'];
		$data['TarifaBase']       = $tarifasB;
		$data['ConvenioBase']     = $conveniosB;
		$data['Tarifa']           = $tarifas;
		$data['Convenio']         = $convenios;
		$repreList = array();
		$representantes = $this->VentaCreditoRepre->importModel("Representantexdestino")->find('all',array('recursive'=>0,'conditions'=>array('Representantexdestino.destino_id'=>$origen)));
		foreach ($representantes as $key => $value) {
			$repreList[$value['Representante']['id']]  = $value['Representante']['identificacion'].' - '.$value['Representante']['listNombre'];
		}
		$data['Representante']    = $repreList;
		return json_encode($data);
	}


	function imprimir($id = null, $Remite = null, $Archiv = null, $Destin = null, $Prueba = null){
		$venta               = $this->VentaCreditoRepre->read(null,$id);
		if($Remite == '1'){
			$envio['hoja'][] = '**REMITENTE**';
		}
		if($Archiv == '1'){
			$envio['hoja'][] = '**ARCHIVO**';
		}
		if($Destin == '1'){
			$envio['hoja'][] = '**DESTINATARIO**';
		}
		if($Prueba == '1'){
			$envio['hoja'][] = '**PRUEBA DE ENTREGA**';
		}
		$envio['n']            = count($envio['hoja']);
		$envio['guia']         = $venta['VentaCreditoRepre']['remesa'];
		$oficinaB              = $this->VentaCreditoRepre->importModel('Oficina')->find('first',array('recursive'=>-1,'fields'=>array('nombre','hasta','desde','resolucion','prefijo','codigo'),'conditions'=>array('Oficina.id'=>$venta['VentaCreditoRepre']['oficina'])));
		$envio['oficina']      = $oficinaB['Oficina']['nombre'];
		$envio['resolucion']   = 'Res. '.$oficinaB['Oficina']['resolucion'].' Autoriza del: '.$oficinaB['Oficina']['prefijo'].$oficinaB['Oficina']['desde'].' al '.$oficinaB['Oficina']['prefijo'].$oficinaB['Oficina']['hasta'];
		$envio['fecha']        = $venta['VentaCreditoRepre']['fecha'];
		$envio['vence']        = $venta['VentaCreditoRepre']['fecha'];
		$envio['factura']      = $venta['VentaCreditoRepre']['facturacion'];
		$envio['servicio']     = 'Envío de Encomiendas';
		$envio['docRef']       = $venta['VentaCreditoRepre']['tipo'].' '.$venta['VentaCreditoRepre']['documento1'];
		$envio['hora']         = $venta['VentaCreditoRepre']['hora'];
		$envio['cliente']      = $venta['VentaCreditoRepre']['nombreClien'];
		$envio['nit']          = $venta['VentaCreditoRepre']['documentoClien'];
		$envio['direccionC']   = $venta['VentaCreditoRepre']['direccionClien'];
		$envio['telefonoC']    = $venta['VentaCreditoRepre']['telefonoClien'];
		$envio['otro_remi']    = $venta['VentaCreditoRepre']['otro_remi'];
		if($venta['VentaCreditoRepre']['otro_remi'] == 0){
			$envio['otro_remi']  = false;
			$envio['remitente']  = "";
			$envio['nitR']       = "";
			$envio['direccionR'] = "";
			$envio['telefonoR']  = "";
		} else {
			$envio['otro_remi']  = true;
			$envio['remitente']  = $venta['VentaCreditoRepre']['nombreRemi'];
			$envio['nitR']       = $venta['VentaCreditoRepre']['documentoRemi'];
			$envio['direccionR'] = $venta['VentaCreditoRepre']['direccionRemi'];
			$envio['telefonoR']  = $venta['VentaCreditoRepre']['telefonoRemi'];		
		}
		
		$origenB               = $this->VentaCreditoRepre->importModel('Destino')->read(null,$venta['VentaCreditoRepre']['origen']);
		$destinoB              = $this->VentaCreditoRepre->importModel('Destino')->read(null,$venta['VentaCreditoRepre']['destino']);
		$envio['origen']       = $origenB['Destino']['nombre'];
		$envio['destino']      = $destinoB['Destino']['nombre'];
		$destinatarioB         = $this->VentaCreditoRepre->importModel('Destinatario')->read(null,$venta['VentaCreditoRepre']['destinatario']);
		$contactoB             = json_decode($destinatarioB['Destinatario']['contacto'],true);
		$envio['destinatario'] = $venta['VentaCreditoRepre']['nombreDest'];
		$envio['ced']          = $venta['VentaCreditoRepre']['documentoDest'];
		$envio['direccionD']   = $venta['VentaCreditoRepre']['direccionDest'];
		$envio['telefonoD1']   = $venta['VentaCreditoRepre']['telefonoDest'];
		$envio['telefonoD2']   = $venta['VentaCreditoRepre']['telefono2Dest'];
		$envio['contacto']     = $contactoB[0]['nombre'];
		$empaques_info         = json_decode($venta['VentaCreditoRepre']['empaque_info'],true);
		$empaquesIguales       = true;
		$sumaFlete             = 0;
		$sumaCantidad          = 0;
		$sumaPeso              = 0;
		$sumaAlto              = 0;
		$sumaAncho             = 0;
		$sumaLargo             = 0;
		$sumaPesoVol           = 0;
		$empaqueAct            = $empaques_info['empaques'][0];
		foreach ($empaques_info['empaques'] as $key => $value) {
			$sumaFlete    = $sumaFlete + ($empaques_info['cantidad'][$key]*$empaques_info['valor'][$key]);
			$sumaLargo    = $sumaLargo + $empaques_info['largo'][$key];
			$sumaAncho    = $sumaAncho + $empaques_info['ancho'][$key];
			$sumaAlto     = $sumaAlto + $empaques_info['alto'][$key];
			$sumaPeso     = $sumaPeso + ($empaques_info['cantidad'][$key]*$empaques_info['peso'][$key]);
			$sumaCantidad = $sumaCantidad + $empaques_info['cantidad'][$key];
			$sumaPesoVol  = $sumaPesoVol + ($empaques_info['cantidad'][$key]*(($empaques_info['largo'][$key]/100)*($empaques_info['ancho'][$key]/100)*($empaques_info['alto'][$key]/100)*400));
			
			if(($empaqueAct != $empaques_info['empaques'][$key]) && ($empaquesIguales)){
				$empaquesIguales = false;
			}
		}
		if($empaquesIguales){
			$empaqueB = $this->VentaCreditoRepre->importModel('Empaque')->read(null, $empaqueAct);
			$envio['empaque'] = $empaqueB['Empaque']['nombre'];
		} else {
			$envio['empaque'] = 'Otros empaques';
		}
		$envio['cantidad']    = $sumaCantidad;
		$envio['peso']        = $sumaPeso;
		$envio['pesoVol']     = $sumaPesoVol;
		if(count($empaques_info['empaques']) > 1){
			$envio['largo']   = "";
			$envio['ancho']   = "";
			$envio['alto']    = "";
		} else {
			$envio['largo']   = $sumaLargo;
			$envio['ancho']   = $sumaAncho;
			$envio['alto']    = $sumaAlto;
		}

		$envio['barras']      = $venta['VentaCreditoRepre']['barras'];
		$envio['observacion'] = $venta['VentaCreditoRepre']['observaciones'];
		$envio['contenido']   = $venta['VentaCreditoRepre']['contenido'];
		$decla = str_replace(".",",",str_replace(",","",$venta['VentaCreditoRepre']['declarado']));
		$envio['valorDecla']  = number_format(floatval($decla),0,'.',',');
		$envio['valorFlete']  = number_format($sumaFlete,0,'.',',');

		$usuarioB = $this->VentaCreditoRepre->importModel('User')->read(null,$venta['VentaCreditoRepre']['usuario']);
		$envio['nombre']       = $usuarioB['User']['name'].' '.$usuarioB['User']['lastname'];
		$envio['formaPago']    = 'CONTADO';
		$envio['kiloAd']       = number_format($venta['VentaCreditoRepre']['kilo_adic'],0,'.',',');
		$envio['valorKiloAd']  = number_format($venta['VentaCreditoRepre']['valor_kilo_adic'],0,'.',',');
		$envio['descFlete']    = number_format($venta['VentaCreditoRepre']['desc_flete'],0,'.',',');
		$envio['descKilo']     = number_format($venta['VentaCreditoRepre']['desc_kilo'],0,'.',',');
		$envio['valorFirmado'] = number_format($venta['VentaCreditoRepre']['valor_devolucion'],0,'.',',');
		$envio['valorSeguro']  = number_format($venta['VentaCreditoRepre']['valor_seguro'],0,'.',',');
		$envio['valorTotal']   = number_format($venta['VentaCreditoRepre']['valor_total'],0,'.',',');
		$envio['kiloNegoc']    = $venta['VentaCreditoRepre']['kilo_nego'];

		$this->set(compact('envio'));
	//	$this->layout = 'pdf'; 
	//	$this->render(); 
	}




}
?>
