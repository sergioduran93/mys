<?php
class Mercancia extends AppModel {
	public $name = 'Mercancia';
	public $displayField = 'nombre';
}
?>
