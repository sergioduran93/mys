<?php
class Recogida extends AppModel {
	public $name = 'Recogida';
}
?>