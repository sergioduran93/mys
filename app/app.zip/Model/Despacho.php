<?php
class Despacho extends AppModel {
	public $name = 'Despacho';
}
?>
