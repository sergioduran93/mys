<?php
class Ingreso extends AppModel {

	//public $belongsTo = array('Conductor');

}
?>
