<?php
class Cartaporte extends AppModel {
	public $name = 'Cartaporte';
}
?>
