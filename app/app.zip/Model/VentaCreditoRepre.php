<?php
class VentasCreditoRepre extends AppModel {
	public $name = 'VentasCreditoRepre';
}
?>
