<?php
class VentaRepre extends AppModel {
	public $name = 'VentaRepre';
}
?>
