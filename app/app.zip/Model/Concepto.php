<?php
class Concepto extends AppModel {
	public $name = 'Concepto';
	
	//public $belongsTo = array('Conductor');

}
?>
