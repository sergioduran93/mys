<?php
class VentaContraentregaRepre extends AppModel {
	public $name = 'VentaContraentregaRepre';
}
?>
