<?php
class Liquidar extends AppModel {
	public $name = 'Liquidar';
}
?>
