<?php
class Nacional extends AppModel {
	public $name         = 'Nacional';

	//public $belongsTo = array('Conductor');

}
?>
