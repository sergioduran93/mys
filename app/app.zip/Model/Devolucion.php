<?php
class Devolucion extends AppModel {
	public $name = 'Devolucion';
}
?>
