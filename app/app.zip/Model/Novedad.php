<?php
class Novedad extends AppModel {
	public $name         = 'Novedad';
	public $displayField = 'novedad';

	//public $belongsTo = array('Conductor');

}
?>
