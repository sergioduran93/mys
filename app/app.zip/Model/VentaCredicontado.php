<?php
class VentaCredicontado extends AppModel {
	public $name = 'VentaCredicontado';
}
?>
